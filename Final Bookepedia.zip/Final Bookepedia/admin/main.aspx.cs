﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
public partial class admin_Default : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }

        var q = obj.feedbacks.Count();

        if (q != null)
        {
            Label l = (Label)Master.FindControl("Label1");

            l.Text = q.ToString();
        }

        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 !=null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }


    }
}