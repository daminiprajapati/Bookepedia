﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class detailspage : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {

        int id = Convert.ToInt32(Request.QueryString["id"]);
        HiddenField1.Value = id.ToString();
        var q = obj.bookDatas.Where(m => m.bid == id).Single();


        Label1.Text = q.bname.ToString();
        Label2.Text = q.authorname.ToString();
        Image1.ImageUrl = q.bimage.ToString();
        Label3.Text = q.price.ToString();
        Label4.Text = q.bdesc.ToString();


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Session["bookid"] = HiddenField1.Value;
        Response.Redirect("buynow1.aspx");
    }
}