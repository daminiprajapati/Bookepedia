﻿
Partial Class admin_admin
    Inherits System.Web.UI.MasterPage

End Class

