﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
public partial class Client_innermain : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {


        if (!IsPostBack)
        {
            DropDownList1.DataSource = obj.categories;
            DropDownList1.DataTextField = "cname";
            DropDownList1.DataValueField = "cid";
            DropDownList1.DataBind();

            DropDownList1.Items.Insert(0, "--SELECT--");
            DropDownList2.Items.Insert(0, "--SELECT--");
            DropDownList3.Items.Insert(0, "--SELECT--");

            DataList1.DataSource = obj.bookDatas.Where(m=>m.qty >0);
            DataList1.DataBind();
        }

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex != 0)
        {
            int id = Convert.ToInt32(DropDownList1.SelectedValue);
            DropDownList2.DataSource = obj.streams.Where(m => m.cid == id);


            DropDownList2.DataTextField = "streamname";
            DropDownList2.DataValueField = "streamid";
            DropDownList2.DataBind();

            DropDownList2.Items.Insert(0, "--SELECT--");


        }
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList2.SelectedIndex != 0)
        {
            int id = Convert.ToInt32(DropDownList2.SelectedValue);
            DropDownList3.DataSource = obj.semesters.Where(m => m.streamid == id);
            DropDownList3.DataTextField = "semname";
            DropDownList3.DataValueField = "semid";
            DropDownList3.DataBind();
            DropDownList3.Items.Insert(0, "--SELECT--");
        }
    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList3.SelectedIndex != 0)
        {
            int id = Convert.ToInt32(DropDownList3.SelectedValue);
            BulletedList1.DataSource = obj.subjects.Where(m => m.semid == id);
            BulletedList1.DataTextField = "subname";
            BulletedList1.DataValueField = "subid";
            BulletedList1.DataBind();
        }
    }
    protected void BulletedList1_Click(object sender, BulletedListEventArgs e)
    {
        int id = Convert.ToInt32(BulletedList1.Items[e.Index].Value);

        DataList1.DataSource = obj.bookDatas.Where(m => m.subid == id & m.qty > 0);
        DataList1.DataBind();
    }
    protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}