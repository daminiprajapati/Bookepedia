﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_bookedit : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(Request.QueryString["id"]);
        HiddenField1.Value = id.ToString();

        var q = obj.bookDatas.Where(m => m.bid == id).Single();

        Label1.Text = q.bname.ToString();

        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(HiddenField1.Value);

        bookData b1 = obj.bookDatas.Where(m => m.bid == id).Single();

        b1.qty = Convert.ToInt32(TextBox1.Text);

        try
        {
            obj.SaveChanges();
            Response.Redirect("order_details.aspx");
        }
        catch
        {

        }

    }
}