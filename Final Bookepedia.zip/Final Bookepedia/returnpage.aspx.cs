﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

using System.Data;
using System.Data.SqlClient;
public partial class returnpage : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();

    protected void Page_Load(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(Session["userid"]);

        string str = @"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\mansi\Desktop\Bookpedia\App_Data\Database.mdf;Integrated Security=True;User Instance=True";
        
        SqlConnection con = new SqlConnection(str);

        con.Open();

        string q = "select b1.buyid,b.bid,b.bname,b.bimage,b.price,b.authorname,b.qty from bookdata b,buynow b1 where b.bid = b1.bid and b1.userid="+id;

        DataSet ds = new DataSet();

        SqlDataAdapter da = new SqlDataAdapter(q,con);

        da.Fill(ds, "table");

        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}