﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_addsemester : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }

        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }
        if (!IsPostBack)
        {
            DropDownList1.DataSource = obj.streams;
            DropDownList1.DataTextField = "streamname";
            DropDownList1.DataValueField = "streamid";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "----select----");
        }

    }
    public void clear()
    {
        DropDownList1.SelectedIndex = 0;
        TextBox1.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string msg = TextBox1.Text;

        int streamid = Convert.ToInt32(DropDownList1.SelectedValue);

        var q = obj.semesters.Where(m => m.semname.Equals(msg) & m.streamid==streamid).SingleOrDefault();

        if (q == null)
        {
            semester s = new semester();
            s.streamid = Convert.ToInt32(DropDownList1.SelectedValue);
            s.semname = TextBox1.Text;
            obj.AddTosemesters(s);
            
            obj.SaveChanges();

            Label2.Text = "Data inserted....";
            clear();
         
        }
        else
        {
            Label2.Text = "Value already Exist";
        }

    }
}