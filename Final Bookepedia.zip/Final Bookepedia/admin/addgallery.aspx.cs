﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_addgalleryt : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }

        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }
    }
    public void clearData()
    {
        TextBox1.Text = "";
        TextBox3.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string rpath = Server.MapPath("image1") + "/";
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(rpath + FileUpload1.FileName);
            string ipath = "~/admin/image1/" + FileUpload1.FileName;

            gallery g = new gallery();
            g.gname = TextBox1.Text;
            g.gpath = ipath.ToString();
            g.gdesc = TextBox3.Text;

            obj.AddTogalleries(g);
            obj.SaveChanges();

            try
            {
                obj.SaveChanges();
                Label2.Text = "Data inserted....";
                clearData();
            }
            catch (Exception e1)
            {
                Label2.Text = "Not inserted....";
            }
        }
        

    }
}