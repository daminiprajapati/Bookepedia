﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class Client_Register : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DropDownList1.DataSource = obj.states;
            DropDownList1.DataTextField = "statename";
            DropDownList1.DataValueField = "stateid";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "--SELECT--");
            DropDownList2.Items.Insert(0, "--SELECT--");


           
        }
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList1.SelectedIndex != 0)
        {
            int id = Convert.ToInt32(DropDownList1.SelectedValue);

            DropDownList2.DataSource = obj.cities.Where(m => m.stateid == id);
            DropDownList2.DataTextField = "cityname";
            DropDownList2.DataValueField = "cityid";
            DropDownList2.DataBind();

            DropDownList2.Items.Insert(0, "--SELECT--");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        register s = new register();
        s.firstname = TextBox1.Text;
        s.lastname = TextBox4.Text;
        s.emailid = TextBox2.Text;
        s.mobile = TextBox6.Text;
        s.password = TextBox3.Text;
        s.cpassword = TextBox5.Text;
        s.dob = TextBox9.Text;
        s.state = Convert.ToInt32(DropDownList1.SelectedValue);
        s.address = TextBox10.Text;
      
        s.city = Convert.ToInt32(DropDownList2.SelectedValue);
        obj.AddToregisters(s);
       // obj.SaveChanges();
        try
        {
            obj.SaveChanges();
            Label3.Text = "Registration Successfully Done";
            clear();
            

        }
        catch (Exception e1)
        {
            Label3.Text = "Not inserted.....";
        }
    }

    public void clear()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
        TextBox6.Text = "";
        TextBox9.Text = "";
        DropDownList1.SelectedIndex = 0;
        DropDownList2.SelectedIndex = 0;
        TextBox10.Text = "";
    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
    protected void CustomValidator1_ServerValidate(object source, ServerValidateEventArgs args)
    {
        if (TextBox6.Text.Length!=10)
        {
            args.IsValid = false;
        }
        else
        {
            args.IsValid = true;
        }

    }
}