﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
using System.Threading;

public partial class contactus : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string howSpicy = "";
        switch (Rating1.CurrentRating)
        {
            case 1:
                howSpicy = "below average";
                break;
            case 2:
                howSpicy = "average";
                break;
            case 3:
                howSpicy = "above average";
                break;
            case 4:
                howSpicy = "good";
                break;
            case 5:
                howSpicy = "excellent";
                break;
        }
        
        feedback f1 = new feedback();
        
        f1.name = TextBox1.Text;
        f1.email = TextBox2.Text;
        f1.contact = TextBox5.Text;
        f1.message = TextBox4.Text;
        f1.frate = howSpicy.ToString();
        obj.AddTofeedbacks(f1);

        try
        {
            obj.SaveChanges();
            Label3.Text = "Thank You For Giving Feedback....";
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";


        }
        catch (Exception e1)
        {
            Label3.Text = "Not inserted.....";
        }
        
    }
    protected void Rating1_Changed(object sender, AjaxControlToolkit.RatingEventArgs e)
    {
        Thread.Sleep(400);
        e.CallbackResult = "Update done. Value = " + e.Value + " Tag = " + e.Tag;
    }
    protected void TextBox5_TextChanged(object sender, EventArgs e)
    {

    }
}