﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_editbook : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }

        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }

        int id = Convert.ToInt32(Request.QueryString["id"]);
        HiddenField1.Value = id.ToString();

        if (!IsPostBack)
        {

            //DropDownList1.DataSource = obj.states;
            //DropDownList1.DataTextField = "statename";
            //DropDownList1.DataValueField = "stateid";
            //DropDownList1.DataBind();

            DropDownList2.DataSource = obj.streams;
            DropDownList2.DataTextField = "streamname";
            DropDownList2.DataValueField = "streamid";
            DropDownList2.DataBind();

            DropDownList3.DataSource = obj.semesters;
            DropDownList3.DataTextField = "semname";
            DropDownList3.DataValueField = "semid";
            DropDownList3.DataBind();

            DropDownList1.DataSource = obj.subjects;
            DropDownList1.DataTextField = "subname";
            DropDownList1.DataValueField = "subid";
            DropDownList1.DataBind();

            var q = obj.bookDatas.Where(m => m.bid == id).Single();

            TextBox1.Text = q.bname.ToString();
            TextBox2.Text = q.authorname.ToString();
            Image1.ImageUrl = q.bimage.ToString();
            HiddenField2.Value = q.bimage.ToString();
            TextBox5.Text = q.price.ToString();
            TextBox3.Text = q.qty.ToString();
            TextBox4.Text = q.bdesc.ToString();
           
                

        }
    }
   
    protected void Button1_Click(object sender, EventArgs e)
    {
       

        int id = Convert.ToInt32(HiddenField1.Value);
        bookData b1 = obj.bookDatas.Where(m => m.bid == id).Single();
        b1.streamid = Convert.ToInt32(DropDownList2.SelectedValue);
        b1.semid = Convert.ToInt32(DropDownList3.SelectedValue);
        b1.subid = Convert.ToInt32(DropDownList1.SelectedValue);
        b1.bname = TextBox1.Text;
        b1.authorname = TextBox2.Text;
        b1.bimage = HiddenField2.Value;
        b1.bimage = Image1.ImageUrl;
        b1.price = Convert.ToInt32(TextBox5.Text);
        b1.qty = Convert.ToInt32(TextBox3.Text);
        b1.bdesc = TextBox4.Text;

        obj.SaveChanges();


        Response.Redirect("managebook.aspx");

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string rpath = Server.MapPath("image1");
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(rpath + FileUpload1.FileName);
            HiddenField2.Value = "~/admin/image1" + FileUpload1.FileName;
            Image1.ImageUrl = "~/admin/image1" + FileUpload1.FileName;
        }
    }
}