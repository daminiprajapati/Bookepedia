﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
public partial class admin_editcity : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }

        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }

        int id = Convert.ToInt32(Request.QueryString["id"]);
        HiddenField1.Value = id.ToString();
        if (!IsPostBack)
        {
            DropDownList1.DataSource = obj.states;
            DropDownList1.DataTextField = "statename";
            DropDownList1.DataValueField = "stateid";
            DropDownList1.DataBind();
            var q = obj.cities.Where(m => m.cityid == id).Single();
            TextBox1.Text = q.cityname.ToString();
            

        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(HiddenField1.Value);
        city c = obj.cities.Where(m => m.cityid == id).Single();
        c.stateid = Convert.ToInt32(DropDownList1.SelectedValue);
        c.cityname = TextBox1.Text;
        obj.SaveChanges();
        Label2.Text = "Data Updated....";
        Response.Redirect("managecity.aspx");
        
    }
}