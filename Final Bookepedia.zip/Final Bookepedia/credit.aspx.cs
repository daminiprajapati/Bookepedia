﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
public partial class credit : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {

        int userid = Convert.ToInt32(Session["userid"]);
        //int userid = 1;
        
        

        var q1 = obj.registers.Where(m => m.userid == userid).Single();

        TextBox1.Text = q1.firstname.ToString() + " " + q1.lastname.ToString();

        TextBox4.Text = q1.address.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("creditbill.aspx");
    }
    protected void TextBox2_TextChanged(object sender, EventArgs e)
    {

    }
}