﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_addcategory : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }
        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }




    }
    public void clear()
    {
        TextBox1.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //Add category button
        string msg = TextBox1.Text;

        var q = obj.categories.Where(m => m.cname.Equals(msg)).SingleOrDefault();

        if (q == null)
        {

            category c = new category();
            c.cname = TextBox1.Text;
            obj.AddTocategories(c);
            obj.SaveChanges();

            try
            {
                obj.SaveChanges();
                Label2.Text = "Data inserted...";
                clear();
            }
            catch (Exception e1)
            {
                Label2.Text = "Not inserted....";
            }
        }
        else
        {
            Label2.Text = "Value already Exist";
        }
    }
}