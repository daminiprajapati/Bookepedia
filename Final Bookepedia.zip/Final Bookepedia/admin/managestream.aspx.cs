﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_managestream : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }
        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }
        gridfill();
    }
    public void gridfill()
    {
        var q = from m in obj.streams join n in obj.categories on m.cid equals n.cid select new { m.streamid, n.cname, m.streamname };
        GridView1.DataSource = q;
        GridView1.DataBind();
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        LinkButton lk = sender as LinkButton;
        GridViewRow gr = lk.NamingContainer as GridViewRow;
        HiddenField hr = (HiddenField)gr.Cells[0].FindControl("hiddenfield1");
        int id = Convert.ToInt32(hr.Value);
        stream s2 = obj.streams.Where(r => r.streamid == id).Single();
        obj.DeleteObject(s2);
        
        obj.SaveChanges();
        gridfill();
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            LinkButton lk = (LinkButton)e.Row.FindControl("linkbutton2");
            lk.Attributes.Add("onclick", "javascript:return add();");
        }
    }
}