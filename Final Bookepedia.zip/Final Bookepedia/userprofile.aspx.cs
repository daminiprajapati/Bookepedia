﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
public partial class Client_userprofile : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(Session["userid"]);

        var q = obj.registers.Where(m => m.userid == id).Single();

        Label1.Text = q.firstname.ToString();

        Label2.Text = q.lastname.ToString();

        Label3.Text = q.emailid.ToString();

        Label4.Text = q.dob.ToString();

    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("editprofile.aspx");
    }
}