﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
public partial class admin_addstate : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }
        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }
    }
    public void clear()
    {
        TextBox1.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string msg = TextBox1.Text;

        var q = obj.streams.Where(m => m.streamname.Equals(msg)).SingleOrDefault();
        if (q == null)
        {
            state s = new state();

            s.statename = TextBox1.Text;
            obj.AddTostates(s);
            try
            {
                obj.SaveChanges();
                Label2.Text = "Data inserted....";
                clear();
            }
            catch (Exception e1)
            {
                Label2.Text = "Not insertted.....";
            }
        }

        else
        {
            Label2.Text = "Value Already Exist";
        }
    }
}