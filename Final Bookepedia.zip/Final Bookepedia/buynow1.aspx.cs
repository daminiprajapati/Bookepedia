﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;


public partial class buynow1 : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    public static int flag = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(Session["userid"]);

        HiddenField1.Value = id.ToString();
        var q = obj.registers.Where(m =>m.userid==id).Single();


        TextBox1.Text = q.firstname.ToString();

        TextBox2.Text = q.lastname.ToString();

        TextBox3.Text = q.emailid.ToString();

        TextBox4.Text = q.mobile.ToString();

        TextBox5.Text = q.address.ToString();
        Session["mode"] = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(HiddenField1.Value);
        if (flag == 1)
        {
            register r = obj.registers.Where(m=>m.userid == id).Single();

            r.address = TextBox5.Text;

            try
            {
                obj.SaveChanges();
                flag = 0;
            }
            catch
            {
            }

            
        }

        if (RadioButton1.Checked)
        {
            Session["mode"] = "Cashondelivery";
            Response.Redirect("cash.aspx");
        }
        else if (RadioButton2.Checked)
        {
            Session["mode"] = "Credit";
            Response.Redirect("credit.aspx");
        }
        else if (RadioButton3.Checked)
        {
            Session["mode"] = "Debit";
            Response.Redirect("debit.aspx");
        }
        
    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox1.Checked)
        {
            flag = 1;
            TextBox5.ReadOnly = false;
        }
        else
        {
            TextBox5.ReadOnly = true;
            flag = 0;
        }
    }
}