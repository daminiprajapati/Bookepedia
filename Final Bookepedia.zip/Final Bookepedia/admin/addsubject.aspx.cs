﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_addsubject : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }
        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }
        if (!IsPostBack)
        {
            DropDownList2.DataSource = obj.streams;
            DropDownList2.DataTextField = "streamname";
            DropDownList2.DataValueField = "streamid";
            DropDownList2.DataBind();
            DropDownList2.Items.Insert(0, "----select----");


            
            DropDownList1.Items.Insert(0, "----select----");
        }

    }
    public void clear()
    {
        TextBox1.Text = "";
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        

        //string msg = TextBox1.Text;

        //var q = obj.subjects.Where(m => m.subname.Equals(msg)).SingleOrDefault();
        //if (q == null)
        //{

            subject s1 = new subject();
            s1.semid = Convert.ToInt32(DropDownList1.SelectedValue);
            s1.streamid = Convert.ToInt32(DropDownList2.SelectedValue);
            s1.subname = TextBox1.Text;
            obj.AddTosubjects(s1);

            try
            {
                obj.SaveChanges();
                Label2.Text = "Data inserted....";
                clear();
            }
            catch (Exception e1)
            {
                Label2.Text = "Not inserted.....";
            }
        //}
        //else
        //{
        //    Label2.Text = "Value already Exit";
        //}
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {

      
        

        if (DropDownList2.SelectedIndex != 0)
        {
            int id = Convert.ToInt32(DropDownList2.SelectedValue);
            DropDownList1.DataSource = obj.semesters.Where(m => m.streamid == id);
            DropDownList1.DataTextField = "semname";
            DropDownList1.DataValueField = "semid";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "----select----");




        }
    }
}