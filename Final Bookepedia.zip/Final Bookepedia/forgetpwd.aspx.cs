﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
using System.Net;
public partial class forgetpwd : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text != "" && TextBox2.Text != "")
        {
            Label1.Text = "please write in one textbox";
        }
        else if (TextBox1.Text != "")
        {
            var q = obj.registers.Where(m => m.emailid.Equals(TextBox1.Text)).Single();

            if (q != null)
            {
                string pwd = q.password.ToString();



            }
        }
        else if (TextBox2.Text != "")
        {
            var q = obj.registers.Where(m => m.mobile.Equals(TextBox2.Text)).Single();

            if (q != null)
            {
                string pwd = "your Password : " + q.password.ToString();

                string mob = q.mobile.ToString();

                Response.Redirect("http://www.onl9class.com/smsapi/smsir.php?email=smith6292@gmail.com&user=smith6292&pass=smit8955&number=" + mob + "&pwd='" + pwd + "'");
            }
            else
            {
                var fromAddress = "mansi@gmail.com";
                var toAddress=TextBox1.Text;
                const string pwd1="12345";
                string subject="your Password";
                string body="password:"+pwd1;   

                


                var smtp = new System.Net.Mail.SmtpClient();
                {
                    smtp.Host = "smtp.gmail.com";
                    smtp.Host = 587;
                    smtp.EnableSsl = true;
                    smtp.DeliveryMethod = System.Net.Mail.SmtpDeliveryMethod.Network;
                    smtp.Credentials = new NetworkCredential(fromAddress, pwd1);
                    smtp.Timeout = 20000;
                }
                smtp.Send(fromAddress, toAddress, subject, body);

            }
        }
    }
}