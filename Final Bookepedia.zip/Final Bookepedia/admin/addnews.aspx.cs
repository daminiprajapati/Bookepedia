﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_addnews : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }
        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string rpath = Server.MapPath("image1") + "/";
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(rpath + FileUpload1.FileName);
            string ipath = "~/admin/image1/" + FileUpload1.FileName;
            news n = new news();
            n.ntitle = TextBox1.Text;
            n.sdesc = TextBox2.Text;
            n.ldesc = TextBox3.Text;
            n.npath = ipath.ToString();
            obj.AddTonews(n);
            obj.SaveChanges();
            try
            {
                obj.SaveChanges();
                Label1.Text = "Data inserted...";
                clearData();

            }
            catch (Exception e1)
            {
                Label1.Text = "Not inserted.....";
            }
        }
    }


        public void clearData()
        {
            TextBox1.Text="";
            TextBox2.Text="";
            TextBox3.Text="";
            
        }

    }
