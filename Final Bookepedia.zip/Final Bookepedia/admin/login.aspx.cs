﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_login : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        Session["user"] = TextBox1.Text;
        Session["pwd"] = TextBox2.Text;
    }
    
    protected void Button1_Click1(object sender, EventArgs e)
    {
       

        var q = (obj.adminLogins.Where(r => r.username.Equals(TextBox1.Text) & r.password.Equals(TextBox2.Text))).SingleOrDefault();
        if (q != null)
        {
            
      
            Label4.Text = "Login Successfully.....";
            Response.Redirect("main.aspx");
        }
        else
        {
            Label4.Text = "Invalid UserName or Password..";
        }
    }
}