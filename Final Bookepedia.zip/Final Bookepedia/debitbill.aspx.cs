﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
public partial class debitbill : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();


    protected void Page_Load(object sender, EventArgs e)
    {
        int bookid = Convert.ToInt32(Session["bookid"]);
        HiddenField5.Value = bookid.ToString();
        //int bookid = 1;
        
        int userid = Convert.ToInt32(Session["userid"]);
        HiddenField6.Value = userid.ToString();
        //int userid = 1;

        var q = obj.bookDatas.Where(m => m.bid == bookid).Single();

        var q1 = obj.registers.Where(m => m.userid == userid).Single();


        Label1.Text = q1.firstname.ToString() + " " + q1.lastname.ToString();
        
        HiddenField1.Value = q1.firstname.ToString();
        HiddenField7.Value = q1.lastname.ToString();

        Label2.Text = q1.mobile.ToString();
        HiddenField8.Value = q1.mobile.ToString();

        Label3.Text = q1.address.ToString();
        HiddenField9.Value = q1.address.ToString();

        Label4.Text = q1.emailid.ToString();


        Label5.Text = q.bname.ToString();
        HiddenField2.Value = q.bname.ToString();

        Label6.Text = q.authorname.ToString();
        Label8.Text = q.price.ToString();
        HiddenField3.Value = q.price.ToString();
        Label10.Text = q.price.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int bid = Convert.ToInt32(HiddenField4.Value);

        bookData b1 = obj.bookDatas.Where(m => m.bid == bid).Single();

        if (b1.qty > 0)
        {
            b1.qty = b1.qty - 1;
        }

        try
        {
            obj.SaveChanges();


            string fname = HiddenField1.Value;
            string lname = HiddenField7.Value;
            string address =HiddenField9.Value  ;
            string contact =HiddenField8.Value ;
            string mode = Session["mode"].ToString();
            int userid = Convert.ToInt32(HiddenField6.Value);
            int bid1=Convert.ToInt32( HiddenField5.Value);
            string bname=HiddenField2.Value;


            buynow b2 = new buynow();

            b2.fname = fname;
            b2.lname = lname;
            b2.address = address;
            b2.contact = contact;
            b2.typeofmode = mode;
            b2.userid = userid;
            b2.bid = bid1;
            b2.bname = bname;

            obj.AddTobuynows(b2);
            obj.SaveChanges();
            Response.Redirect("https://www.paypal.com/cgi-bin/webscr?cmd=_xclick&business=" + HiddenField1.Value + "@paypal.com&item_name=" + HiddenField2.Value + "&amount=" + HiddenField3.Value + "&currency_code=USD");
        }
        catch
        {

        }
 
    }
}