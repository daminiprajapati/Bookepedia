﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
public partial class loginclient : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
        var q = obj.registers.Where(m => m.emailid.Equals(TextBox1.Text) & m.password.Equals(TextBox2.Text)).SingleOrDefault();

        if (q != null)
        {
            Session["userid"] = q.userid.ToString();
            Response.Redirect("innermain.aspx");
        }
        else
        {
            Label1.Text = "invalid user or pwd";
        }
    }
}