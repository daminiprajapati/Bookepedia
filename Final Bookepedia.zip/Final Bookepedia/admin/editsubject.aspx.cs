﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;
public partial class admin_editsubject : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }

        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }
        int id = Convert.ToInt32(Request.QueryString["id"]);
        HiddenField1.Value = id.ToString();
        if (!IsPostBack)
        {
            var q = obj.subjects.Where(m => m.subid == id).Single();



            DropDownList1.DataSource = obj.semesters;
            DropDownList1.DataTextField = "semname";
            DropDownList1.DataValueField = "semid";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "----select----");
            DropDownList1.Text = q.semid.ToString();
            TextBox1.Text = q.subname.ToString();


        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
          int id=Convert.ToInt32(HiddenField1.Value);
        subject s=obj.subjects.Where(m=>m.subid==id).Single();
          s.semid= Convert.ToInt32(DropDownList1.SelectedValue);
        s.subname = TextBox1.Text;
        obj.SaveChanges();
        Label2.Text="Data Updated....";
        Response.Redirect("managesubject.aspx");

    }
}