﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class Client_editprofile : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(Session["userid"]);
        HiddenField1.Value = id.ToString();
        if (!IsPostBack)
        {
            var q = obj.registers.Where(m => m.userid == id).Single();

            TextBox1.Text = q.firstname.ToString();

            TextBox2.Text = q.lastname.ToString();

            TextBox3.Text = q.emailid.ToString();

            TextBox4.Text = q.dob.ToString();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(HiddenField1.Value);

        register q = obj.registers.Where(m => m.userid == id).Single();

        q.firstname = TextBox1.Text;
        q.lastname = TextBox2.Text;
        q.emailid = TextBox3.Text;
        q.dob = TextBox4.Text;

        try
        {
            obj.SaveChanges();
            Response.Redirect("userprofile.aspx");
        }
        catch
        {
        }
    }
}