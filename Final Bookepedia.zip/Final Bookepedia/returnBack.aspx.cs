﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class returnBack : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        int id = Convert.ToInt32(Session["userid"]);

        int bid = Convert.ToInt32(Request.QueryString["id"]);

        var q = (from m in obj.registers where m.userid == id select m).Single();

        int cityid = Convert.ToInt32(q.city);


        var q1 = (from m in obj.cities where m.cityid == cityid select m).Single();


        var q2 = (from m in obj.bookDatas where m.bid == bid select m).Single();
        
        Label2.Text = q2.bname.ToString() ;

        int price = Convert.ToInt32(q2.price);

        int fprice = (price*40)/100;

        int dprice = price-fprice;

        Label3.Text = dprice.ToString();

        Label1.Text = q1.cityname.ToString();
    }
}