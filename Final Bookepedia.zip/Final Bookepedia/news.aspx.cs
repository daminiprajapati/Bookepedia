﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class news : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        DataList1.DataSource = obj.news;
        DataList1.DataBind();
    }
}