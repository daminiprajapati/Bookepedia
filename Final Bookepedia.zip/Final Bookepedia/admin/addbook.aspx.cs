﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DatabaseModel;

public partial class admin_addbook : System.Web.UI.Page
{
    DatabaseEntities1 obj = new DatabaseEntities1();
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["user"].ToString() == "" && Session["pwd"].ToString() == "")
            {
                Response.Redirect("login.aspx");
            }
        }
        catch
        {
            Response.Redirect("login.aspx");
        }
        var q1 = obj.bookDatas.Where(m => m.qty == 0).Count();

        if (q1 != null)
        {
            Label l1 = (Label)Master.FindControl("Label2");
            l1.Text = q1.ToString();
        }



        if (!IsPostBack)
        {
            DropDownList2.DataSource = obj.streams;
            DropDownList2.DataTextField = "streamname";
            DropDownList2.DataValueField = "streamid";
            DropDownList2.DataBind();
            DropDownList2.Items.Insert(0, "----select----");



            DropDownList1.Items.Insert(0, "----select----");
            DropDownList3.Items.Insert(0, "----select----");
        }


    }

    public void clearData()
    {
        TextBox1.Text = "";
     
        TextBox2.Text = "";
        
        TextBox4.Text = "";
        TextBox5.Text = "";
       
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string rpath = Server.MapPath("image1") + "/";
        if (FileUpload1.HasFile)
        {
            FileUpload1.SaveAs(rpath + FileUpload1.FileName);
            string ipath = "~/admin/image1/" + FileUpload1.FileName;



            bookData b2 = new bookData();
            b2.streamid = Convert.ToInt32(DropDownList2.SelectedValue);
            b2.semid = Convert.ToInt32(DropDownList3.SelectedValue);

           
           b2.subid = Convert.ToInt32(DropDownList1.SelectedValue);
            
            

            b2.bname = TextBox1.Text;
            b2.authorname = TextBox2.Text;
            b2.bimage = ipath.ToString();
            b2.price = Convert.ToInt32(TextBox5.Text);
            b2.qty = Convert.ToInt16(TextBox3.Text);
            b2.bdesc = TextBox4.Text;

            obj.AddTobookDatas(b2);
            obj.SaveChanges();

            try
            {
                obj.SaveChanges();
                Label2.Text = "Data inserted....";
                clearData();


            }
            catch (Exception e1)
            {
                Label2.Text = "Not inserted.....";
            }
        }
    }
    protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList2.SelectedIndex != 0)
        {
            int id = Convert.ToInt32(DropDownList2.SelectedValue);
            DropDownList3.DataSource = obj.semesters.Where(m => m.streamid == id);
            DropDownList3.DataTextField = "semname";
            DropDownList3.DataValueField = "semid";
            DropDownList3.DataBind();
            DropDownList3.Items.Insert(0, "----select----");





        }

    }
    protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DropDownList3.SelectedIndex != 0)
        {
            int id = Convert.ToInt32(DropDownList3.SelectedValue);
            DropDownList1.DataSource = obj.subjects.Where(m => m.semid == id);
            DropDownList1.DataTextField = "subname";
            DropDownList1.DataValueField = "subid";
            DropDownList1.DataBind();
            DropDownList1.Items.Insert(0, "----select----");
        }


    }
}